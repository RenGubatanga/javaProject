/**
 * 
 */
/**
 * 
 */
module javaSwing1 {
	requires java.desktop;
}