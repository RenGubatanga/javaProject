package javaSwing1;

import javax.swing.JFrame;

public class Swing1 extends JFrame{
	Swing1(){
		this.setSize(420, 420);
		this.setTitle("Ren");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
	}
}
