package javaSwing1;

public class Main {
    public static void main(String[] args) {

       // Login_menu login = new Login_menu();
      /Menu menu = new Menu();
    	//ServicesWindow services = new ServicesWindow();
    	//HomePage home = new HomePage();
    	//new AppointmentWindow();
    	//new ServicesWindow();
    }
}